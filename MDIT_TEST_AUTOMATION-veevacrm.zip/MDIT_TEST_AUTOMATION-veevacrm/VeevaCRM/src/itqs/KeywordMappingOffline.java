package itqs;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;

public class KeywordMappingOffline {
	static String className = "Keywordmapping";

	public enum KeyWord {
		LAUNCH_APP, ENTER_DATA_IN_TEXTFIELD, CLICKBUTTON, WAIT_FOR_ELEMENT_TO_BE_VISIBLE, CLEARVAL, ENTER_FREETEXT,
		SENDMAIL, SCROLL, SIGNATURE, WAITFOR,VERIFY_TEXT,WAITING,MOVE_DOWN,REMOVE_EMAIL_ADDRESS,WAIT,CLOSE_APP
	}

	public static int keywordActionMapping(Driver dobj) {
		int executionStatus;
		By locator;
		executionStatus = 1;
		locator = null;

		KeyWord enumKeyWordValue = KeyWord.valueOf(dobj.TestStep_Keyword_Used.toUpperCase());
		try {
			switch (enumKeyWordValue) {

			case LAUNCH_APP:
				Driver.driver = GenericKeywords.launchMobileDevice(GenericKeywords.getConfigDetails("MobileAppType"));
				executionStatus = GenericKeywords.openApp(Driver.driver, "com.lilly.iRep");
				break;

			case ENTER_DATA_IN_TEXTFIELD:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.inputDataIntoTextbox(Driver.driver, locator, dobj.Data_Step_Value);
				break;

			case WAITFOR:
				GenericKeywords.waitForTime(Driver.driver, 3);
				break;

			case CLICKBUTTON:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus=GenericKeywords.clickButton(Driver.driver, locator);
				break;

			case WAIT:
				Driver.driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
				break;
				
			case SIGNATURE:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.enterSignature(Driver.driver, locator);
				break;

			case WAIT_FOR_ELEMENT_TO_BE_VISIBLE:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.wait_For_Element_To_Be_Visible(Driver.driver, 30, locator);
				break;

			case SENDMAIL:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.sendEmail(Driver.driver, locator);
				break;

			case SCROLL:
				SpecificKeywords.scrolling(Driver.driver);
				break;
				
			case REMOVE_EMAIL_ADDRESS:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				SpecificKeywords.removeEmailAdd(Driver.driver,locator);
				break;	
				
			case VERIFY_TEXT:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.verifyTxt(Driver.driver, locator,dobj.Data_Step_Value);
				break;
				
			case WAITING:
				Thread.sleep(1000);
				break;
				
			case MOVE_DOWN:
				SpecificKeywords.moveDown(Driver.driver);
				break;
				
			case CLOSE_APP:
				Driver.driver.quit();
				executionStatus = 1;
				break;

			default:
				break;
			}
		} catch (Exception e) {
			executionStatus = -1;
			LoggerClass.WriteToLog(className, enumKeyWordValue.toString() + " KeyWord Failed : " + e.getMessage());
		}
		return executionStatus;
	}
}

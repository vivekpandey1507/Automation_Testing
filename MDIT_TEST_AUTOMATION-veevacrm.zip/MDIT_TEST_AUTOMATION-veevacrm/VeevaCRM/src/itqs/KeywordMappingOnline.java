package itqs;

import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;

public class KeywordMappingOnline {
	static String className = "Keywordmapping";

	public enum KeyWord {
		OPENAPP, KILLBROWSER, SETEDITBOX, CLICKBUTTON, WAIT, CHECK_LEFTPANE_CHECKBOX, SELECT_MODULE, SELECT_CUSTOMER_ID,
		ENTER_DETAILS_DATA_STEWARD_SCREEN_TEXT_BOX_CUSTOMERID, SELECT_DROPDOWN, SELECT_COMMERCIAL_OPTION, WAITFOR,
		REVIEW_CONSENT_ONE, CHECK_CONFIRMATION_MESSAGE, IS_ELEMENT_EXIST, DROPDOWN_MENU_ACCESSABLE,
		ENTER_ACCOUNT_NAME_ADV_SEARCH_FR, CLICK_EMAIL_TEMLATE_CHECKBOXES, SELECT_FROM_DROPDOWN, REVIEW_CONSENT,

		// Enter other Keyword values here
		OTHER, SETEDITBOX_MULTIPLE_FIELDS, BLANK_CHECK, CHECK_FORMAT, ENTER_ACCOUNT_EDIT_EMAIL_FULL2,
		REVIEW_CONSENTWITHOUTPHONE, ENTER_ACCOUNT_NAME_ADV_SEARCH_FR_EXIT, WAIT_FOR_MEDICAL_REQUEST_PAGE,
		WAIT_FOR_ELEMENT_TO_BE_VISIBLE, VERIFY_RECORDTYPE, MEDICAL_REQUEST_FR, VERIFY_STATUS,
		SELECT_FROM_DROPDOWN_INDEX, SELECT_FROM_DROPDOWN_TEXT, ENTER_MEDICAL_REQUEST_FR, VERIFY_STATUS_ALL,
		VERFYINGREADONLY, ENTER_SURVEY_FR, UPDATE_MEETING_NAME, UPDATE_MEETING_NAME_REP, ENTER_MEDICAL_REQUEST_FR_OUT,
		SELECT_FROM_DROPDOWN_TEXT_DYNAMIC, UPDATE_LOT_NAME_REP,

		SCROLL_DOWN, BASE_SCROLL_DOWN, INTERACTION_FRAME, TLMAP_FRAME, SCROLL_DOWN_PAGE, ENTER_CONTRACTED_ACTIVITY,
		ENTER_ACCOUNT_PLAN_SHARE, ENTER_INTERACTION_FRAME, ENTER_LIGHTNING_FRAME,
	}

	public static int keywordActionMapping(Driver dobj) {
		int executionStatus;
		By locator;
		executionStatus = 1;
		locator = null;

		KeyWord enumKeyWordValue = KeyWord.valueOf(dobj.TestStep_Keyword_Used.toUpperCase());
		try {
			switch (enumKeyWordValue) {

			case OPENAPP:
				Driver.driver = GenericKeywords.launchBrowser(GenericKeywords.getConfigDetails("BrowserDetails"));
				executionStatus = GenericKeywords.openApplication(Driver.driver, dobj.Data_Step_Value);
				// executionStatus=1;
				break;

			case KILLBROWSER:
				executionStatus = SpecificKeywords.exitBrowser(Driver.driver);
				// executionStatus=1;
				break;

			case SETEDITBOX:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				if (GenericKeywords.isElementExist(Driver.driver, locator)) {
					executionStatus = GenericKeywords.setEditBox(Driver.driver, locator, dobj.Data_Step_Value);
				} else {
					executionStatus = 0;
				}
				break;

			case CLICKBUTTON:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				if (GenericKeywords.isElementExist(Driver.driver, locator)) {
					GenericKeywords.clickButton(Driver.driver, locator);
					executionStatus = 1;
				} else {
					executionStatus = 0;
				}
				break;

			case WAIT:
				Driver.driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
				executionStatus = 1;
				break;

			case WAIT_FOR_ELEMENT_TO_BE_VISIBLE:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.wait_For_Element_To_Be_Visible(Driver.driver, 30, locator);
				break;

			case WAIT_FOR_MEDICAL_REQUEST_PAGE:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				// executionStatus=GenericKeywords.wait_For_Medical_Request_Page(Driver.driver,9,locator);
				GenericKeywords.wait_For_Medical_Request_Page(Driver.driver, 9, locator);
				break;

			case CHECK_LEFTPANE_CHECKBOX:
				executionStatus = SpecificKeywords.checkLeftPaneCheckBox(Driver.driver, dobj.Data_Step_Value);
				break;

			case SELECT_MODULE:
				executionStatus = SpecificKeywords.selectModule(Driver.driver, dobj.Data_Step_Value);
				break;

			case SELECT_CUSTOMER_ID:
				executionStatus = SpecificKeywords.selectCustomerRadioButton(Driver.driver, dobj.Data_Step_Value);
				break;

			case ENTER_DETAILS_DATA_STEWARD_SCREEN_TEXT_BOX_CUSTOMERID:
				executionStatus = SpecificKeywords.enterDetailsToDataStewardScreenTextBoxCustomerID(Driver.driver,
						dobj.Data_Step_Value);
				break;

			case SELECT_DROPDOWN:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				if (GenericKeywords.isElementExist(Driver.driver, locator)) {
					executionStatus = SpecificKeywords.selectDropdownOption(Driver.driver, locator,
							dobj.Data_Step_Value);
				} else {
					executionStatus = 0;
				}
				break;

			case WAITFOR:
				GenericKeywords.waitForTime(Driver.driver, 3);
				break;

			case SELECT_COMMERCIAL_OPTION:
				executionStatus = SpecificKeywords.selectCommercialOption(Driver.driver, dobj.Data_Step_Value);
				break;

			case IS_ELEMENT_EXIST:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				if (GenericKeywords.isElementExist(Driver.driver, locator))
					executionStatus = 1;
				else
					executionStatus = 0;
				break;

			case DROPDOWN_MENU_ACCESSABLE:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.IsDropDownMenuAccessable(Driver.driver, locator);
				break;

			case ENTER_ACCOUNT_NAME_ADV_SEARCH_FR:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.cssSelector("iframe[title='LILLY_ADVANCED_SEARCH']")));
				executionStatus = GenericKeywords.setEditBox(Driver.driver, locator, dobj.Data_Step_Value);
				break;

			case ENTER_ACCOUNT_NAME_ADV_SEARCH_FR_EXIT:
				Driver.driver.switchTo().defaultContent();
				break;

			case ENTER_MEDICAL_REQUEST_FR:
				Driver.driver.switchTo().frame(Driver.driver.findElement(By.cssSelector("iframe[title='Content']")));
				break;

			case ENTER_SURVEY_FR:
				Driver.driver.switchTo().frame(Driver.driver.findElement(By.cssSelector("iframe[title='Content']")));
				break;

			case ENTER_ACCOUNT_EDIT_EMAIL_FULL2:
				Thread.sleep(3000);
				Driver.driver.switchTo().frame(Driver.driver.findElement(By.cssSelector("iframe[title='Content']")));
				break;

			case CLICK_EMAIL_TEMLATE_CHECKBOXES:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.emailTemplateCheckboxes(Driver.driver, locator);
				break;

			case SELECT_FROM_DROPDOWN:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				GenericKeywords.select_from_dropdown(Driver.driver, locator, dobj.Data_Step_Value);
				break;

			case REVIEW_CONSENT:
				SpecificKeywords.reviewConsent(Driver.driver);
				break;

			case VERIFY_RECORDTYPE:
				executionStatus = SpecificKeywords.verifyRecordType(Driver.driver);
				break;

			case MEDICAL_REQUEST_FR:
				GenericKeywords.switch_To_Frame(Driver.driver, "itarget");
				break;

			case VERIFY_STATUS:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.verifyStatus(Driver.driver, locator);
				break;

			case VERIFY_STATUS_ALL:
				String Status_Value = dobj.Data_Step_Value;
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.StatusCheck(Driver.driver, Status_Value, locator);
				break;

			case SELECT_FROM_DROPDOWN_INDEX:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.select_from_dropdown_index(Driver.driver, locator, 1);
				break;

			case SELECT_FROM_DROPDOWN_TEXT:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.select_from_dropdown_text(Driver.driver, locator,
						dobj.Data_Step_Value);
				break;
				
			case REVIEW_CONSENTWITHOUTPHONE:
				SpecificKeywords.reviewConsentwithoutphone(Driver.driver);
				break;

			case BLANK_CHECK:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.checkBlank(Driver.driver, locator);
				break;

			case CHECK_FORMAT:
				String Datasheetvalue = dobj.Data_Step_Value;
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.checkFormat(Driver.driver, Datasheetvalue, locator);
				break;

			case VERFYINGREADONLY:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				if (GenericKeywords.isElementExist(Driver.driver, locator)) {
					executionStatus = 1;
				} else {
					executionStatus = 0;
				}
				break;

			case UPDATE_MEETING_NAME:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = SpecificKeywords.UPDATEMEETINGNAME(Driver.driver, locator, dobj.Data_Step_Value);
				break;

			case UPDATE_MEETING_NAME_REP:
				String updatedmeetingvaluename = SpecificKeywords.ConcateMeeting;
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.cssSelector("iframe[title='LILLY_ADVANCED_SEARCH']")));
				executionStatus = GenericKeywords.setEditBox(Driver.driver, locator, updatedmeetingvaluename);
				break;

			case ENTER_MEDICAL_REQUEST_FR_OUT:
				Driver.driver.switchTo().defaultContent();
				break;

			case SELECT_FROM_DROPDOWN_TEXT_DYNAMIC:

				String updatedmeetingvaluename2 = SpecificKeywords.ConcateMeeting;
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.select_from_dropdown_text(Driver.driver, locator,
						updatedmeetingvaluename2);
				break;

			case UPDATE_LOT_NAME_REP:

				String updatedLotvaluename = SpecificKeywords.ConcateMeeting;
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.setEditBox(Driver.driver, locator, updatedLotvaluename);
				break;

			case INTERACTION_FRAME:
				Thread.sleep(3000);
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.xpath("(//iframe[starts-with(@name,'vfFrameId')])[4]")));
				Thread.sleep(3000);
				break;

			case ENTER_INTERACTION_FRAME:
				Thread.sleep(3000);
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.xpath("(//iframe[starts-with(@name,'vfFrameId')])[5]")));
				Thread.sleep(3000);
				break;

			case TLMAP_FRAME:
				Thread.sleep(3000);
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.xpath("(//iframe[starts-with(@name,'vfFrameId')])[1]")));
				Thread.sleep(3000);
				break;

			case ENTER_LIGHTNING_FRAME:
				Thread.sleep(3000);
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.xpath("(//iframe[starts-with(@name,'vfFrameId')])[2]")));
				Thread.sleep(3000);
				break;

			case ENTER_CONTRACTED_ACTIVITY:
				Thread.sleep(3000);
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.xpath("(//iframe[starts-with(@name,'vfFrameId')])[3]")));
				Thread.sleep(3000);
				break;

			case ENTER_ACCOUNT_PLAN_SHARE:
				Thread.sleep(3000);
				Driver.driver.switchTo()
						.frame(Driver.driver.findElement(By.xpath("(//iframe[starts-with(@name,'vfFrameId')])[5]")));
				Thread.sleep(3000);
				break;

			case SCROLL_DOWN:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.scroll_down(Driver.driver, locator);
				break;

			case SCROLL_DOWN_PAGE:
				locator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(dobj.TestStep_ObjectName));
				executionStatus = GenericKeywords.scroll_down(Driver.driver, locator);
				break;

			case BASE_SCROLL_DOWN:
				GenericKeywords.base_scroll_down(Driver.driver, 2);
				break;

			case OTHER:
				executionStatus = 0;
				break;
				
			case CHECK_CONFIRMATION_MESSAGE:
				executionStatus = 0;
				break;
				
			case SETEDITBOX_MULTIPLE_FIELDS:
				executionStatus = 0;
				break;
				
			default:
				break;
			}
		} catch (Exception e) {
			executionStatus = -1;
			LoggerClass.WriteToLog(className, enumKeyWordValue.toString() + " KeyWord Failed : " + e.getMessage());
		}
		return executionStatus;
	}
}

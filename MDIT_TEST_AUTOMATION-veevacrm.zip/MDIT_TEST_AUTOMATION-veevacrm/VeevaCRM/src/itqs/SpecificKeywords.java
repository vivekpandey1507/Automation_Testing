package itqs;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class SpecificKeywords {

	// SpecificKeywords.logger=Logger.getLogger("SpecificKeywords");
	static String className = "SpecificKeywords";
	public static String ConcateMeeting;

	public static int exitBrowser(WebDriver driver) {
		int local_Result;
		driver.quit();
		local_Result = 1;
		return local_Result;
	}

	public static int getchildElementCount(WebDriver driver, String parentWebElement, String childWebElement) {
		int subElementCountValue;
		subElementCountValue = 0;
		By parentLocator, childLocator;
		WebElement parentAvailableWebElement;
		List<WebElement> chileWebElements = null;
		parentLocator = null;
		childLocator = null;
		parentAvailableWebElement = null;
		try {
			parentLocator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(parentWebElement));
			childLocator = GenericKeywords.getbjectLocator(GenericKeywords.getOR(childWebElement));

			if (!(parentLocator.equals(null) && childLocator.equals(null))) {
				parentAvailableWebElement = driver.findElement(parentLocator);
				if (!parentAvailableWebElement.equals(null)) {
					chileWebElements = parentAvailableWebElement.findElements(childLocator);
					subElementCountValue = chileWebElements.size();
				} else {
					subElementCountValue = -1;
				}
			} else {
				subElementCountValue = -1;
			}
		} catch (Exception e) {
			subElementCountValue = -1;
			LoggerClass.WriteToLog(className, "getChildElementCount");
		}
		return subElementCountValue;
	}

	public static int checkLeftPaneCheckBox(WebDriver driver, String checkBoxLebelValue) {
		int abletoCheck;
		abletoCheck = 0;
		String checkBoxXPath = "";
		WebElement checkBoxObject = null;
		checkBoxXPath = "//*[text()='" + checkBoxLebelValue + "']/parent::*/parent::*/input[@type='checkbox']";
		checkBoxObject = driver.findElement(By.xpath(checkBoxXPath));
		if (!(checkBoxObject.equals(null) && checkBoxObject.isSelected())) {
			checkBoxObject.click();
			abletoCheck = 1;
		} else {
			abletoCheck = 0;
		}
		return abletoCheck;
	}

	public static int selectModule(WebDriver driver, String searchableObjectName) throws Exception {
		int local_Result;
		local_Result = 1;
		String objectxPath = ".//div[@id='centerWrapper']//span[contains(text(),'" + searchableObjectName + "')]";
		WebElement element;
		element = driver.findElement(By.xpath(objectxPath));
		if (element.getSize() != null && element.isDisplayed()) {
			element.click();
			local_Result = 1;
		} else {
			local_Result = 0;

		}
		return local_Result;
	}

	public static int selectCustomerRadioButton(WebDriver driver, String radioButtonObject) {
		int local_Result;
		local_Result = 1;
		String objectxPath = ".//div[@id='divradio1']//label[contains(text(),'" + radioButtonObject
				+ "')]/preceding-sibling::*";
		WebElement element;
		element = driver.findElement(By.xpath(objectxPath));
		if (element.getSize() != null && element.isDisplayed()) {
			element.click();
			SharedVariableClass.insertValueToStringMap("CUSTOMER_RADIO", radioButtonObject);
			local_Result = 1;
		} else {
			local_Result = 0;

		}
		return local_Result;
	}

	public static int enterDetailsToDataStewardScreenTextBoxCustomerID(WebDriver driver, String valuetoEnter) {
		int local_Result;
		local_Result = 1;
		WebElement element;
		String CustomerRadioDetails;

		CustomerRadioDetails = SharedVariableClass.getSharedvariableValue("CUSTOMER_RADIO");
		try {

			if (CustomerRadioDetails.contains("Customer")) {
				element = driver.findElement(
						GenericKeywords.getbjectLocator(GenericKeywords.getOR("DataStewardScreen_TextBox_CustomerID")));
			} else {
				element = driver.findElement(
						GenericKeywords.getbjectLocator(GenericKeywords.getOR("DataStewardScreen_TextBox_AltID")));
			}
			element.click();
			element.clear();
			element.sendKeys(valuetoEnter);
			local_Result = 1;
			LoggerClass.WriteToLog(className, "enterDetailsToDataStewardScreenTextBoxCustomerID: Data Entered");
		} catch (Exception e) {

			local_Result = 0;
			LoggerClass.WriteToLog(className,
					"enterDetailsToDataStewardScreenTextBoxCustomerID: Data not able Entered");
		}
		return local_Result;
	}

	public static int selectDropdownOption(WebDriver driver, By locator, String optionValue) {
		int local_Result;
		int Index_value;
		Boolean optionFoundFlag;
		Select drpCountry;
		List<WebElement> optionList;
		drpCountry = null;
		local_Result = 1;
		WebElement element;
		element = driver.findElement(locator);
		optionFoundFlag = false;
		Index_value = 0;

		if (element.isDisplayed()) {
			drpCountry = new Select(element);
			optionList = drpCountry.getOptions();
			for (WebElement el : optionList) {
				if (el.getText().toUpperCase().equals(optionValue.toUpperCase())) {
					drpCountry.selectByIndex(Index_value);
					optionFoundFlag = true;
					break;
				}
				++Index_value;
			}
		}
		if (optionFoundFlag) {
			local_Result = 1;
		} else {
			local_Result = 0;
		}
		return local_Result;
	}

	public static int selectCommercialOption(WebDriver driver, String OptionValue) throws Exception {
		int local_Result;
		local_Result = 0;
		String xPathValue = ".//*[@id='entitlementsListDiv']//*[contains(text(),'" + OptionValue
				+ "')]/preceding-sibling::input[@type='checkbox']";

		WebElement element;
		element = driver.findElement(By.xpath(xPathValue));
		if (element.isDisplayed()) {
			element.click();
			local_Result = 1;
		} else {
			local_Result = 0;
		}
		return local_Result;
	}

	public static boolean WebObjectFluentWait(WebDriver driver, int pollingEveryTimeSecond, int timeOutSecond,
			WebElement element) {
		boolean webElementPresence = false;
		try {
			Wait<WebDriver> fluentWait = new FluentWait<WebDriver>(driver)
					.pollingEvery(pollingEveryTimeSecond, TimeUnit.SECONDS).withTimeout(timeOutSecond, TimeUnit.SECONDS)
					.ignoring(NoSuchElementException.class);
			fluentWait.until(ExpectedConditions.visibilityOf(element));
			if (element.isDisplayed()) {
				webElementPresence = true;
			}
		} catch (Exception e) {
			LoggerClass.WriteToLog(className,
					"ERROR: Timeout waiting for webelement to be present : " + e.getMessage());

		}

		return webElementPresence;
	}

	public static int IsDropDownMenuAccessable(WebDriver driver, By locator) {
		int local_Result;
		local_Result = 0;
		WebElement element;
		element = driver.findElement(locator);

		if (element.isDisplayed()) {
			element.click();
			local_Result = 1;
		} else
			local_Result = 0;
		return local_Result;
	}

	/* This Function is click the check box by Switching the iframe */
	public static int emailTemplateCheckboxes(WebDriver driver, By locator) {
		int Local_result;
		try {
			Driver.driver.switchTo().frame("vod_iframe");
			Driver.driver.findElement(locator).click();
			Local_result = 1;
		} catch (Exception e) {
			Local_result = 0;
		}
		return Local_result;
	}

	/* This Function is click the check box by using the java executor */
	public static void reviewConsent(WebDriver driver) throws InterruptedException {
		driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
		WebElement we = driver.findElement(By.xpath("//span[text()='Phone Consent ']"));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", we);
		Thread.sleep(3000);
		driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
	}

	public static void reviewConsentwithoutphone(WebDriver driver) throws InterruptedException {
		driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
	}

	/* This Function is checking the blank value is present in the field or not */
	public static int checkBlank(WebDriver driver, By locator) {
		String Email1;
		int Local_result;
		WebElement A = driver.findElement(locator);
		Email1 = A.getAttribute("value");
		if (!Email1.isEmpty()) {
			Local_result = 0;
		} else {
			Local_result = 1;
		}
		return Local_result;
	}

	/* This Function is changing the value in the UTF-8 Format */
	public static int checkFormat(WebDriver driver, String Datasheetvalue, By locator)
			throws UnsupportedEncodingException {

		String text;
		int Local_result = 0;
		WebElement A = driver.findElement(locator);
		text = A.getText();
		String[] doublecommaseparray = text.split(";;");
		String[] commaseparray = Datasheetvalue.split(",");
		for (int j = 0; j < commaseparray.length; j++) {
			String textEnteredValue = Base64.getEncoder().encodeToString(commaseparray[j].getBytes("utf-8"));
			for (int i = 0; i < doublecommaseparray.length; i++) {
				String textEncodedValue = Base64.getEncoder().encodeToString(doublecommaseparray[i].getBytes("utf-8"));
				if (textEncodedValue.contentEquals(textEnteredValue)) {
					Local_result = 1;
				}
			}
		}
		return Local_result;
	}

	/* This Function is Verify the record type is interaction */
	public static int verifyRecordType(WebDriver driver) throws InterruptedException {
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[text()='Record Type']")));
		Thread.sleep(2000);
		Select select = new Select(driver.findElement(By.xpath("//select[@id='RecordTypeId']")));
		WebElement option = select.getFirstSelectedOption();
		String defaultItem = option.getText();
		if (defaultItem.equals("Interaction")) {
			return 1;
		} else
			return 0;
	}

	/* This Function is Verify the status has been submitted or saved */
	public static int verifyStatus(WebDriver driver, By locator) {
		String status = driver.findElement(locator).getText();
		if (status.equals("Submitted") || status.equals("Saved")) {
			return 1;
		}
		return 0;
	}

	/* This Function is Verify the status of the field */
	public static int StatusCheck(WebDriver driver, String Status_Value, By locator) {
		String planstatus = driver.findElement(locator).getText();
		if (planstatus.equals(Status_Value)) {
			return 1;
		}
		return 0;
	}

	/* This Function is updated the speaker meeting name with date time stamp */
	public static int UPDATEMEETINGNAME(WebDriver driver, By locator, String userEnteredValue) {
		ConcateMeeting = userEnteredValue + (new SimpleDateFormat("MM/dd/yyyy HH:mm:ss")).format(new Date());
		int functionReturnResult;
		functionReturnResult = -1;
		Integer executionStatus = GenericKeywords.setEditBox(Driver.driver, locator, ConcateMeeting);
		if (executionStatus > 0) {
			functionReturnResult = 1;
		} else {
			functionReturnResult = 0;
		}
		return functionReturnResult;
	}

	public static int sendEmail(WebDriver driver, By locator) {
		int local_Result;
		IOSElement email = (IOSElement) driver.findElement(locator);
		email.setValue("1%");
		local_Result = 1;
		return local_Result;
	}

	public static void scrolling(WebDriver driver) {
		int x = driver.manage().window().getSize().width / 2;
		int lowerY = driver.manage().window().getSize().height * 4 / 5;
		int upperY = driver.manage().window().getSize().height / 13;
		GenericKeywords.scroll(driver, x, lowerY, x, upperY);
	}

	public static int enterSignature(WebDriver driver, By locator) {
		int local_Result;
		WebElement we = driver.findElement(locator);
		GenericKeywords.swipe(driver, "right", 2000, we);
		local_Result = 1;
		return local_Result;
	}

	public static int verifyTxt(WebDriver driver, By locator, String text) {
		String screenTxt = driver.findElement(locator).getText();
		if (text.equals(screenTxt)) {
			return 1;
		}
		return 0;
	}

	public static void moveDown(WebDriver driver) {
		int x = driver.manage().window().getSize().width / 2;
		int lowerY = driver.manage().window().getSize().height * 4 / 5;
		int upperY = driver.manage().window().getSize().height / 5;
		GenericKeywords.scroll(driver, x, lowerY, x, upperY);
	}

	public static int removeEmailAdd(WebDriver driver, By locator) {
		driver.findElement(locator).clear();
		return 1;
	}
}
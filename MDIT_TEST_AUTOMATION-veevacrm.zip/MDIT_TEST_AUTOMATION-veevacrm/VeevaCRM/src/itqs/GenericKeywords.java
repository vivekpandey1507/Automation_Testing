package itqs;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
//import java.sql.Connection;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.net.URL;
//import javax.xml.parsers.DocumentBuilder;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.Borders;
import org.apache.poi.xwpf.usermodel.BreakType;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.TextAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableCell.XWPFVertAlign;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STTblWidth;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class GenericKeywords {

	static String configFileLocation;
	static String ObjectRepositoryFileLocation;
	static String className = "GenericKeywords";

	public static void Initialize() {
		configFileLocation = "./Resources/configuration.property";
		ObjectRepositoryFileLocation = "./Resources/ObjectRepository.property";
	}

	@SuppressWarnings("deprecation")
	public static WebDriver launchBrowser(String BrowserType) throws IOException {
		WebDriver driver;
		driver = null;
		if (BrowserType.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", GenericKeywords.getConfigDetails("fireFoxDriverPath"));
			driver = new FirefoxDriver();
		}
		if (BrowserType.equalsIgnoreCase("ie")) {
		}
		if (BrowserType.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", GenericKeywords.getConfigDetails("chromeDriverPath"));
			driver = new ChromeDriver();
			driver.get("https://www.google.com/");
			LoggerClass.WriteToLog(className, "LaunchBrowser : Chrome Browser launched");
		}
		if (BrowserType.equalsIgnoreCase("chrome_sl")) {
			String accessKey = GenericKeywords.getConfigDetails("SauceLabAccessKey");
			String sauceLabUserName = GenericKeywords.getConfigDetails("SauceLabUserName");
			String sauceLabTestCaseName = GenericKeywords.getConfigDetails("SauceLabTestCaseName");
			String sauceLabTagName = GenericKeywords.getConfigDetails("SauceLabTagName");
			System.setProperty("http.proxyHost", "proxy.gtm.lilly.com");
			System.setProperty("http.proxyPort", "9000");
			DesiredCapabilities caps = DesiredCapabilities.chrome();
			caps.setCapability("platform", "Windows 10");
			caps.setCapability("browser", "Chrome");
			caps.setCapability("version", "91.0");
			caps.setCapability("name", sauceLabTestCaseName);
			caps.setCapability("tags", sauceLabTagName);
			driver = new RemoteWebDriver(
					new URL("http://" + sauceLabUserName + ":" + accessKey + "@ondemand.saucelabs.com:80/wd/hub"),
					caps);
		}
		return driver;
	}

	public static int openApplication(WebDriver driver, String URL) {
		int local_Result;
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.get(URL);
		LoggerClass.WriteToLog(className, "OpenApplication : Application Launched");
		local_Result = 1;
		return local_Result;
	}

	public static String getConfigDetails(String findKey) {
		String keyValue;
		keyValue = "";
		try {
			File configSourceFile = new File(configFileLocation);
			FileInputStream fis = new FileInputStream(configSourceFile);
			Properties propertyDetails = new Properties();
			propertyDetails.load(fis);
			keyValue = propertyDetails.getProperty(findKey);
			LoggerClass.WriteToLog(className, "getConfigDetails : Configuration Details Fetched");
		} catch (Exception e) {
			LoggerClass.WriteToLog(className, "getConfigDetails : Configuration Details does not Fetched");
		}
		return keyValue;
	}

	public static String getOR(String ORKey) {
		String ORValue;
		ORValue = "";
		try {
			File configSourceFile = new File(ObjectRepositoryFileLocation);
			FileInputStream fis = new FileInputStream(configSourceFile);
			Properties propertyDetails = new Properties();
			propertyDetails.load(fis);
			ORValue = propertyDetails.getProperty(ORKey);
			LoggerClass.WriteToLog(className, "getOR : OR Details Fetched");
		} catch (Exception e) {
			LoggerClass.WriteToLog(className, "getOR : OR Details does not Fetched");
		}
		return ORValue;
	}

	public static By getbjectLocator(String locatorProperty) throws Exception {
		String locatorType = locatorProperty.split(":")[0];
		String locatorValue = locatorProperty.split(":")[1];
		By locator = null;
		if (locatorType.equalsIgnoreCase("Id"))
			locator = By.id(locatorValue);
		else if (locatorType.equalsIgnoreCase("Name"))
			locator = By.name(locatorValue);
		else if (locatorType.equalsIgnoreCase("CssSelector"))
			locator = By.cssSelector(locatorValue);
		else if (locatorType.equalsIgnoreCase("LinkText"))
			locator = By.linkText(locatorValue);
		else if (locatorType.equalsIgnoreCase("PartialLinkText"))
			locator = By.partialLinkText(locatorValue);
		else if (locatorType.equalsIgnoreCase("TagName"))
			locator = By.tagName(locatorValue);
		else if (locatorType.equalsIgnoreCase("Xpath"))
			locator = By.xpath(locatorValue);
		LoggerClass.WriteToLog(className, "getbjectLocator : Object Locator Identified");
		return locator;
	}

	public static int getWebElementCount(WebDriver driver, By locator) {
		List<WebElement> WebElementList = driver.findElements(locator);
		LoggerClass.WriteToLog(className, "getWebElementCount : Get webelement count");
		return WebElementList.size();
	}

	public static int setEditBox(WebDriver driver, By locator, String userEnteredValue) {
		int functionReturnResult;
		functionReturnResult = -1;
		WebElement element;
		if (GenericKeywords.getWebElementCount(driver, locator) > 0) {
			element = driver.findElement(locator);
			element.click();
			element.clear();
			element.sendKeys(userEnteredValue);
			functionReturnResult = 1;
			LoggerClass.WriteToLog(className, "setEditBox : Data entered");
		} else {
			functionReturnResult = 0;
			LoggerClass.WriteToLog(className, "setEditBox : Data does not entered");
		}
		return functionReturnResult;
	}

	public static int clickButton(WebDriver driver, By locator) {
		int Local_Result;
		try {
			driver.findElement(locator).click();
			Local_Result = 1;
			LoggerClass.WriteToLog(className, "clickButton : Button have been clicked");
		} catch (Exception e) {
			LoggerClass.WriteToLog(className, "clickButton : Button not clicked ::" + e.getMessage());
			Local_Result = 0;
		}
		return Local_Result;
	}

	public static Boolean isElementExist(WebDriver driver, By locator) {
		LoggerClass.WriteToLog(className, "isElementExist : Element Exist");
		return driver.findElement(locator).isDisplayed();

	}


	public static int getSQLRecordCount(String excelFileLocation, String SQLQuery) {
		int localRecordCount;
		localRecordCount = 0;
		Fillo fillo = new Fillo();
		Connection connection = null;
		try {
			connection = fillo.getConnection(excelFileLocation);
			Recordset recordset = connection.executeQuery(SQLQuery);
			localRecordCount = recordset.getCount();
			recordset.close();
			connection.close();
			LoggerClass.WriteToLog(className, "getSQLRecordCount : get Record counts ");
		} catch (Exception e) {
			localRecordCount = -1;
			LoggerClass.WriteToLog(className, "getSQLRecordCount : Record counts in negative ");
		}
		return localRecordCount;
	}

	public static String getSQLRecord(String excelFileLocation, String SQLQuery, int recordCountNumber,
			String fieldName) {
		String RecordValue;
		RecordValue = "";
		int localRecordCount;
		Fillo fillo = new Fillo();
		Connection connection = null;
		try {
			connection = fillo.getConnection(excelFileLocation);
			Recordset recordset = connection.executeQuery(SQLQuery);
			localRecordCount = recordset.getCount();
			if (localRecordCount > 0) {
				if (localRecordCount >= recordCountNumber) {
					for (int i = 1; i <= recordCountNumber; i++) {
						recordset.next();
					}
					LoggerClass.WriteToLog(className, "getSQLRecord : get SQL Record details ");
					RecordValue = recordset.getField(fieldName);
				} else
				{
					LoggerClass.WriteToLog(className, "getSQLRecord :  SQL Record details in negative ");
					RecordValue = "-1";
				}
			} else {
				LoggerClass.WriteToLog(className, "getSQLRecord :  SQL Record details is zero ");
				RecordValue = "" + 0;
			}
			recordset.close();
			connection.close();
		} catch (Exception e) {
			RecordValue = "-1";
		}
		return RecordValue;
	}

	public static int executeKeyWord(Driver dobj) {
		int keywordExecutionStatus;
		keywordExecutionStatus = 1;
		if (dobj.TestCase_Type.equals("Online")) {
			LoggerClass.WriteToLog(className, "executeKeyWord :  Keyword execution Start ");
			keywordExecutionStatus = KeywordMappingOnline.keywordActionMapping(dobj);
		} else {
			keywordExecutionStatus = KeywordMappingOffline.keywordActionMapping(dobj);
		}
		return keywordExecutionStatus;
	}

	public static void takeScreenShot(WebDriver driver, String FileName) {
		try {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(scrFile, new File(FileName));
		} catch (Exception e) {
		}
	}

	public static XWPFDocument createWordDocument(String FileName) {
		XWPFDocument document = null;
		File fileObj = new File(FileName);

		if (!fileObj.exists()) {
			document = new XWPFDocument();
			return document;
		} else {
			try {
				FileInputStream fis = new FileInputStream(FileName);
				document = new XWPFDocument(OPCPackage.open(fis));
			} catch (Exception e) {
			}
			return document;
		}
	}

	public static void writeToWordDocument(XWPFDocument document, String FileName) {
		try {
			FileOutputStream out = new FileOutputStream(new File(FileName));
			document.write(out);
			out.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public static void writeTextToWordDocument(XWPFDocument document, String TextToAdd, int alignment) {
		XWPFParagraph subTitle = document.createParagraph();
		if (alignment == 0) {
			subTitle.setAlignment(ParagraphAlignment.LEFT);
		} else if (alignment == 1) {
			subTitle.setAlignment(ParagraphAlignment.CENTER);
		}
		XWPFRun subTitleRun = subTitle.createRun();
		subTitleRun.setFontSize(16);
		subTitleRun.setBold(true);
		subTitleRun.setUnderline(UnderlinePatterns.SINGLE);
		subTitleRun.setText(TextToAdd.trim());

	}

	public static void addBreakToWordDocument(XWPFDocument document, String breaktype) {
		XWPFParagraph subTitle = document.createParagraph();
		XWPFRun subTitleRun = subTitle.createRun();
		if (breaktype.equalsIgnoreCase("page")) {
			subTitleRun.addBreak(BreakType.PAGE);
		} else if (breaktype.equalsIgnoreCase("line")) {
			subTitleRun.addBreak(BreakType.TEXT_WRAPPING);
		}
	}

	public static void addImageToWordDocument(XWPFDocument document, String imageFileName) {
		XWPFParagraph subTitle = document.createParagraph();
		subTitle.setAlignment(ParagraphAlignment.LEFT);
		subTitle.setBorderBottom(Borders.BASIC_THIN_LINES);
		subTitle.setBorderTop(Borders.BASIC_THIN_LINES);
		subTitle.setBorderLeft(Borders.BASIC_THIN_LINES);
		subTitle.setBorderRight(Borders.BASIC_THIN_LINES);
		XWPFRun subTitleRun = subTitle.createRun();
		try {
			FileInputStream pic = new FileInputStream(imageFileName);
			subTitleRun.addPicture(pic, XWPFDocument.PICTURE_TYPE_PNG, imageFileName, Units.toEMU(450),
					Units.toEMU(300));
			subTitleRun.addBreak(BreakType.PAGE);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void deleteFile(String FileName) {
		try {
			File file = new File(FileName);
			if (file.exists()) {
				file.delete();
			} else {
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	public static XWPFTable createTableToWordDocument(XWPFDocument document, String dataValue, long bigIntegerValue,
			String alignmentValue) {
		XWPFTableCell VCell;
		XWPFTable table = document.createTable();
		VCell = table.getRow(0).getCell(0);
		VCell.setVerticalAlignment(XWPFVertAlign.TOP);
		XWPFParagraph paragraph = VCell.addParagraph();
		XWPFRun run = paragraph.createRun();
		if (alignmentValue.equalsIgnoreCase("left")) {
			paragraph.setAlignment(ParagraphAlignment.LEFT);
		} else if (alignmentValue.equalsIgnoreCase("center")) {
			paragraph.setAlignment(ParagraphAlignment.CENTER);
		}
		paragraph.setVerticalAlignment(TextAlignment.TOP);
		paragraph.setWordWrapped(true);
		run.setText(dataValue.trim());
		table.getRow(0).getCell(0).getCTTc().addNewTcPr().addNewTcW().setType(STTblWidth.DXA);
		table.getRow(0).getCell(0).getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(bigIntegerValue));
		return table;
	}

	public static XWPFTableRow createTableRowToWordDocument(XWPFTable table) {
		XWPFTableRow tableRow = table.createRow();
		return tableRow;
	}

	public static void addCellAndSetCellValueOfTableToWordDocument(XWPFTable table, int RowNumber, String DataValue,
			long bigIntegerValue, String alignmentValue) {
		XWPFTableCell VCell;
		VCell = table.getRow(RowNumber).createCell();
		VCell.setVerticalAlignment(XWPFVertAlign.TOP);
		XWPFParagraph paragraph = VCell.addParagraph();
		paragraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun run = paragraph.createRun();
		run.setText(DataValue.trim());
		if (alignmentValue.equalsIgnoreCase("left")) {
			paragraph.setAlignment(ParagraphAlignment.LEFT);
		} else if (alignmentValue.equalsIgnoreCase("center")) {
			paragraph.setAlignment(ParagraphAlignment.CENTER);
		}
		paragraph.setVerticalAlignment(TextAlignment.TOP);
		paragraph.setWordWrapped(true);
		// VCell.setText(DataValue);
		VCell.getCTTc().addNewTcPr().addNewTcW().setType(STTblWidth.DXA);
		VCell.getCTTc().addNewTcPr().addNewTcW().setW(BigInteger.valueOf(bigIntegerValue));
	}

	public static void SetCellValueOfTableToWordDocument(XWPFTable table, int CellRowNumber, int CellColumnNumber,
			String DataValue, String alignmentValue) {
		XWPFTableCell VCell;
		VCell = table.getRow(CellRowNumber).getCell(CellColumnNumber);
		VCell.setVerticalAlignment(XWPFVertAlign.TOP);
		XWPFParagraph paragraph = VCell.addParagraph();
		paragraph.setAlignment(ParagraphAlignment.LEFT);
		paragraph.setWordWrapped(true);
		XWPFRun run = paragraph.createRun();
		run.setText(DataValue.trim());
		// GenericKeywords.deleteTableCellTextOfTableToWordDocument(table,CellRowNumber,CellColumnNumber,DataValue);
		if (alignmentValue.equalsIgnoreCase("left")) {
			paragraph.setAlignment(ParagraphAlignment.LEFT);
		} else if (alignmentValue.equalsIgnoreCase("center")) {
			paragraph.setAlignment(ParagraphAlignment.CENTER);
		}
		paragraph.setVerticalAlignment(TextAlignment.TOP);
	}

	public static void deleteTableCellTextOfTableToWordDocument(XWPFTable table, int CellRowNumber,
			int CellColumnNumber, String DataValue) {
		XWPFTableCell VCell;
		XWPFParagraph currectParagraph;
		List<XWPFParagraph> existingParagraphList;
		XWPFDocument doc;
		int paragraphPosition;
		VCell = table.getRow(CellRowNumber).getCell(CellColumnNumber);
		existingParagraphList = VCell.getParagraphs();
		if (existingParagraphList.size() > 0) {
			for (int pg = 0; pg <= existingParagraphList.size() - 1; pg++) {
				currectParagraph = existingParagraphList.get(pg);
				if (currectParagraph.getText().equalsIgnoreCase(DataValue)) {
					doc = currectParagraph.getDocument();
					paragraphPosition = doc.getPosOfParagraph(currectParagraph);
					doc.removeBodyElement(paragraphPosition);
				}
			}
		}
	}

//****need to work
	public static int getWordDocumentTableColumnIndex(XWPFTable table, int CellRowNumber, String cellDataValue) {
		int columnIndex;
		columnIndex = -1;
		List valueDetails;
		XWPFTableCell VCell;
		// VCell.get
		// VCell.
		valueDetails = table.getRow(CellRowNumber).getTableCells();
		for (int ik = 0; ik < valueDetails.size(); ik++) {
			// System.out.println(" vaue 123: " +
			// table.getRow(CellRowNumber).getCell(ik).getText());

		}
		return columnIndex;
	}

//********************

	public static int getWordTableRowIndex(XWPFTable table, String fieldValue) {
		int rowIndex;
		String textValue;
		rowIndex = -1;
		List<XWPFTableCell> cells;
		for (int i = 0; i < table.getNumberOfRows(); i++) {
			cells = table.getRow(i).getTableCells();
			textValue = cells.get(0).getText().toString();
			if (fieldValue.equalsIgnoreCase(table.getRow(i).getCell(0).getText())) {

				break;
			}
		}
		return rowIndex;
	}

	public static void setRowOrColumnColor(XWPFTable table, String RowColumn, String coloreCode) {
		if (RowColumn.equalsIgnoreCase("row")) {
			for (int i = 0; i < table.getRow(0).getTableCells().size(); i++) {
				table.getRow(0).getCell(i).setColor(coloreCode);
			}
		} else if (RowColumn.equalsIgnoreCase("column")) {
			for (int j = 0; j < table.getNumberOfRows(); j++) {
				table.getRow(j).getCell(0).setColor(coloreCode);

			}
		}
	}

	public static void waitForTime(WebDriver driver, int timeInSeconds) {
		WebElement element;
		WebDriverWait wait;
		element = null;
		wait = null;
		try {
			wait = new WebDriverWait(driver, timeInSeconds);
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//Veeva CRM Automation")));
		} catch (Exception e) {
		}
	}

	public static int createTXTfile(String FilePath, String FileName) {
		int local_Result;
		local_Result = 1;
		String Full_File_Path;
		if (FilePath.lastIndexOf("/") == FilePath.length() - 1) {
			Full_File_Path = FilePath + FileName;
		} else {
			Full_File_Path = FilePath + "/" + FileName;
		}
		File fileObject = new File(Full_File_Path);
		try {
			if (!fileObject.exists()) {
				fileObject.createNewFile();
				local_Result = 1;
			}
		} catch (Exception e) {
			System.out.println("Error at createTXTfile : " + e.getMessage());
			local_Result = 0;
		}
		fileObject = null;
		return local_Result;
	}

	public static void WriteToTXTFile(String FilePath, String FileName, String valueToWrite) {
		String Full_File_Path;
		if (FilePath.lastIndexOf("/") == FilePath.length() - 1) {
			Full_File_Path = FilePath + FileName;
		} else {
			Full_File_Path = FilePath + "/" + FileName;
		}
		File fileObject = new File(Full_File_Path);
		try {
			FileOutputStream fos = new FileOutputStream(fileObject, false);
			Writer writer = new BufferedWriter(new OutputStreamWriter(fos, "utf-8"));
			writer.write("" + valueToWrite);
			writer.close();
		} catch (Exception e) {
			System.out.println("Error at WriteToTXTFile : " + e.getMessage());
		}
		fileObject = null;
	}

	public static void deleteMultiple_File_With_Specific_Word_In_Name_FromFolder(String FilePath,
			String WordInFileName) {
		File folder = new File(FilePath);
		File[] files = folder.listFiles();
		for (File singleFile : files) {
			if (singleFile.getName().contains(WordInFileName)) {
				singleFile.delete();
			}
		}
	}

	public static void select_from_dropdown(WebDriver driver, By locator, String textToBeSelected) {
		WebElement we;
		we = driver.findElement(locator);
		Select slObj = new Select(we);
		slObj.selectByVisibleText(textToBeSelected);
	}

	public static int wait_For_Element_To_Be_Visible(WebDriver driver, int timeToWait, By locator) {

		int local_result;
		WebDriverWait wait = new WebDriverWait(driver, timeToWait);
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			local_result = 1;
		} catch (Exception e) {
			local_result = 0;
		}
		return local_result;
	}

	public static void wait_For_Medical_Request_Page(WebDriver driver, int timeToWait, By locator) {
		switch_To_Frame(driver, "itarget");
	}

	public static void switch_To_Frame(WebDriver driver, String frameNameOrId) {
		try {
			driver.switchTo().frame(frameNameOrId);
		} catch (Exception e) {
		}
	}

	public static int select_from_dropdown_index(WebDriver driver, By locator, int index) {
		int local_result;
		WebElement we;
		try {
			we = driver.findElement(locator);
			Select slObj = new Select(we);
			slObj.selectByIndex(index);
			local_result = 1;
		} catch (Exception e) {
			local_result = 0;
		}
		return local_result;
	}

	public static int select_from_dropdown_text(WebDriver driver, By locator, String text) {
		int local_result;
		WebElement we;
		try {
			we = driver.findElement(locator);
			Select slObj = new Select(we);
			slObj.selectByVisibleText(text);
			local_result = 1;
		} catch (Exception e) {
			local_result = 0;
		}
		return local_result;
	}

//code to scroll down to specific element
	public static int scroll_down(WebDriver driver, By locator) {
		int local_result;
		WebElement element;
		try {
			JavascriptExecutor je = (JavascriptExecutor) driver;
			element = driver.findElement(locator);
			je.executeScript("arguments[0].scrollIntoView(true);", element);
			local_result = 1;
		} catch (Exception e) {
			local_result = 0;
		}
		return local_result;
	}

//code to scroll down to specific element inside the webelement
	public static int scroll_down_page(WebDriver driver, By locator) {
		int local_result;

		try {
			JavascriptExecutor je = (JavascriptExecutor) driver;
			WebElement element = driver.findElement(locator);
			je.executeScript("arguments[0].scrollIntoView(true)", element);
			local_result = 1;
		} catch (Exception e) {
			local_result = 0;
		}
		return local_result;
	}

//code to scroll down the bar vertically 
	public static void base_scroll_down(WebDriver driver, int timeInSeconds) {
		WebElement element;
		element = null;
		try {
			JavascriptExecutor jsx = (JavascriptExecutor) driver;
			jsx.executeScript("window.scrollBy(0,500)", "");
		} catch (Exception e) {
			System.out.println("Veeva CRM  :" + e.getMessage());
		}
	}

	public static WebDriver launchMobileDevice(String appDetails) throws MalformedURLException {
		WebDriver driver = null;
		if (appDetails.equalsIgnoreCase("ios")) {
			String accessKey = GenericKeywords.getConfigDetails("SauceLabAccessKey");
			String sauceLabUserName = GenericKeywords.getConfigDetails("SauceLabUserName");
			System.setProperty("https.proxyHost", "proxy.gtm.lilly.com");
			System.setProperty("https.proxyPort", "9000");
			DesiredCapabilities caps1 = new DesiredCapabilities();
			caps1.setCapability("platformName", "iOS");
			caps1.setCapability("deviceName", "iPad Pro 12.9 2018");
			caps1.setCapability("platformVersion", "14.6");
			driver = new IOSDriver<WebElement>(new URL(
					"https://" + sauceLabUserName + ":" + accessKey + "@ondemand.us-west-1.saucelabs.com/wd/hub"),
					caps1);
		}
		return driver;
	}

	@SuppressWarnings("unchecked")
	public static int openApp(WebDriver driver, String identifier) {
		int local_Result;
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("bundleId", identifier);
		((JavascriptExecutor) driver).executeScript("mobile:launchApp", map);
		((AppiumDriver<WebElement>) driver).context("NATIVE_APP");
		local_Result = 1;
		return local_Result;
	}

	public static int inputDataIntoTextbox(WebDriver driver, By locator, String userEnteredValue) {
		int local_Result;
		driver.findElement(locator).sendKeys(userEnteredValue);
		local_Result = 1;
		return local_Result;
	}

	public static void scroll(WebDriver driver, int X, int Y, int tillX, int tillY) {
		TouchAction touchAction = new TouchAction((PerformsTouchActions) driver);
		touchAction.longPress(X, Y).moveTo(tillX, tillY).release().perform();
	}

	public static void swipe(WebDriver driver, String dir, int vel, WebElement element) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		Map<String, Object> map = new HashMap<>();
		map.put("direction", dir);
		map.put("velocity", vel);
		map.put("element", ((RemoteWebElement) element).getId());
		jse.executeScript("mobile: swipe", map);
	}
}

package itqs;

import org.apache.log4j.Logger;

public class LoggerClass {
	
	static Logger logger;
	
	public static void WriteToLog(String className,String ValueToLog)
	{
		//logger=Logger.getLogger(className);	
		//logger.info(ValueToLog);
		
	}

}

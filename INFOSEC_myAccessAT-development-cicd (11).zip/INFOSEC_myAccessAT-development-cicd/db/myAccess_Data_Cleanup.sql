--Bulk Delete Audit Event Data for Action "update" and Source "Scheduler" and target like 'ManagedAttribute%' where created before 2 years 
BEGIN
LOOP
    DELETE FROM IDENTITYIQ_OWNER.SPT_AUDIT_EVENT  WHERE 
    ACTION = 'update' AND SOURCE = 'Scheduler' 
	AND TARGET LIKE 'ManagedAttribute:%' AND 
	((CAST(SYS_EXTRACT_UTC(CAST(TRUNC(SYSDATE) AS TIMESTAMP WITH TIME ZONE)- INTERVAL '2' YEAR) AS DATE)-DATE '1970-01-01')*86400000) >= CREATED
    AND ROWNUM < 5000;    
    EXIT WHEN SQL%rowcount < 1;
    COMMIT;
END LOOP;
COMMIT;
END;

--Bulk Delete system logs where created before 13 months
BEGIN
LOOP
    DELETE FROM IDENTITYIQ_OWNER.SPT_SYSLOG_EVENT WHERE 
    ((CAST(SYS_EXTRACT_UTC(CAST(TRUNC(SYSDATE) AS TIMESTAMP WITH TIME ZONE)- INTERVAL '13' MONTH) AS DATE)-DATE '1970-01-01')*86400000) >= CREATED
    AND ROWNUM < 5000;    
    EXIT WHEN SQL%rowcount < 1;
    COMMIT;
END LOOP;
COMMIT;
END;
